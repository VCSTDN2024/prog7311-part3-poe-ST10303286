﻿namespace AgriEnergyConnectPrototype.Models.ViewModels
{
    /// <summary>
    /// ViewModel representing a farmer along with the count of products they have added.
    /// Used primarily for dashboard or reporting purposes where a summary is needed.
    /// </summary>
    public class FarmerWithProductCount
    {
        /// <summary>
        /// Gets or sets the unique identifier of the farmer.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the farmer.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Gets or sets the total number of products associated with this farmer.
        /// </summary>
        public int ProductCount { get; set; }
    }
}
