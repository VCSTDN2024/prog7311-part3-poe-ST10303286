﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgriEnergyConnectPrototype.Models
{
    /// <summary>
    /// Represents an agricultural product added by a farmer.
    /// Includes details like name, category, production date, and farmer association.
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Gets or sets the unique identifier for the product.
        /// Serves as the primary key in the database.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the product (e.g., "Apple", "Corn").
        /// This field is required and limited to 50 characters.
        /// </summary>
        [Required(ErrorMessage = "Product name is required.")]
        [StringLength(50, ErrorMessage = "Product name cannot exceed 50 characters.")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the category of the product (e.g., "Fruit", "Vegetable").
        /// This field is required and limited to 30 characters.
        /// </summary>
        [Required(ErrorMessage = "Product category is required.")]
        [StringLength(30, ErrorMessage = "Category cannot exceed 30 characters.")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets the production date of the product.
        /// This field is required and used for filtering and freshness tracking.
        /// </summary>
        [Required(ErrorMessage = "Production date is required.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ProductionDate { get; set; }

        /// <summary>
        /// Gets or sets the ID of the farmer who created this product.
        /// Foreign key to the Farmer table.
        /// </summary>
        [ForeignKey("Farmer")]
        public int FarmerId { get; set; }

        /// <summary>
        /// Navigation property to the farmer who owns this product.
        /// </summary>
        public Farmer Farmer { get; set; }
    }
}
