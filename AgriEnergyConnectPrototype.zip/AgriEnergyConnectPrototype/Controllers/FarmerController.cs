﻿using AgriEnergyConnectPrototype.Data;
using AgriEnergyConnectPrototype.Models;
using AgriEnergyConnectPrototype.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AgriEnergyConnectPrototype.Controllers
{
    public class FarmerController : BaseController
    {
        private readonly AppDbContext _context;
        private readonly ValidationService _validationService;

        public FarmerController(
            IHttpContextAccessor accessor,
            AppDbContext context,
            ValidationService service)
            : base(accessor)
        {
            _context = context;
            _validationService = service;
        }

        // ✅ Farmer Dashboard
        public IActionResult Index()
        {
            if (!IsAuthorized("Farmer"))
                return RedirectToLogin();

            int? farmerId = _httpContextAccessor.HttpContext.Session.GetInt32("UserId");
            if (farmerId == null)
                return RedirectToLogin();

            var products = _context.Products
                                   .Where(p => p.FarmerId == farmerId)
                                   .ToList();

            return View("Dashboard", products);
        }

        // ✅ GET: Add Product Form
        public IActionResult AddProduct()
        {
            if (!IsAuthorized("Farmer"))
                return RedirectToLogin();

            return View();
        }

        // ✅ POST: Add Product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddProduct(Product product)
        {
            if (!IsAuthorized("Farmer"))
                return RedirectToLogin();

            int farmerId = _httpContextAccessor.HttpContext.Session.GetInt32("UserId") ?? 0;
            product.FarmerId = farmerId;

            if (!_validationService.ValidateProduct(product.Name, product.Category, product.ProductionDate.ToString(), out var errorMsg))
            {
                ModelState.AddModelError("", errorMsg);
                return View(product);
            }

            try
            {
                await _context.Products.AddAsync(product);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Product added!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding product: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while saving the product.");
                return View(product);
            }
        }

        // ✅ GET: Edit Product
        public IActionResult EditProduct(int id)
        {
            if (!IsAuthorized("Farmer"))
                return RedirectToLogin();

            var product = _context.Products.FirstOrDefault(p => p.Id == id);
            int? farmerId = _httpContextAccessor.HttpContext.Session.GetInt32("UserId");

            if (product == null || product.FarmerId != farmerId)
                return NotFound();

            return View(product); // 🔄 Make sure /Views/Farmer/EditProduct.cshtml exists
        }

        // ✅ POST: Edit Product
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProduct(Product updatedProduct)
        {
            if (!IsAuthorized("Farmer"))
                return RedirectToLogin();

            if (!_validationService.ValidateProduct(updatedProduct.Name, updatedProduct.Category, updatedProduct.ProductionDate.ToString(), out var msg))
            {
                ModelState.AddModelError("", msg);
                return View(updatedProduct);
            }

            var existingProduct = await _context.Products.FindAsync(updatedProduct.Id);
            int? farmerId = _httpContextAccessor.HttpContext.Session.GetInt32("UserId");

            if (existingProduct == null || existingProduct.FarmerId != farmerId)
                return NotFound();

            existingProduct.Name = updatedProduct.Name;
            existingProduct.Category = updatedProduct.Category;
            existingProduct.ProductionDate = updatedProduct.ProductionDate;

            try
            {
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Product updated!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Update failed: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while updating the product.");
                return View(updatedProduct);
            }
        }
    }
}
