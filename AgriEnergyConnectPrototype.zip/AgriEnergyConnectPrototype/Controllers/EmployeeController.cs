﻿using AgriEnergyConnectPrototype.Data;
using AgriEnergyConnectPrototype.Models;
using AgriEnergyConnectPrototype.Models.ViewModels;
using AgriEnergyConnectPrototype.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AgriEnergyConnectPrototype.Controllers
{
    public class EmployeeController : BaseController
    {
        private readonly AppDbContext _context;
        private readonly ValidationService _validationService;

        public EmployeeController(
            IHttpContextAccessor httpContextAccessor,
            AppDbContext context,
            ValidationService validationService)
            : base(httpContextAccessor)
        {
            _context = context;
            _validationService = validationService;
        }

        public IActionResult Index()
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            var farmersWithCounts = _context.Farmers
                .Select(f => new FarmerWithProductCount
                {
                    Id = f.Id,
                    Name = f.Name,
                    ProductCount = _context.Products.Count(p => p.FarmerId == f.Id)
                }).ToList();

            return View("EmpDashboard", farmersWithCounts);
        }

        public IActionResult AddFarmer()
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddFarmer(Farmer farmer)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            if (!_validationService.ValidateFarmer(farmer.Name, farmer.ContactInfo, out var errorMessage))
            {
                ModelState.AddModelError("", errorMessage);
                return View(farmer);
            }

            try
            {
                await _context.Farmers.AddAsync(farmer);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Farmer added successfully!";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding farmer: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while saving. Please try again.");
                return View(farmer);
            }
        }

        public IActionResult ViewProducts(int farmerId)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            var products = _context.Products
                .Where(p => p.FarmerId == farmerId)
                .ToList();

            ViewBag.FarmerName = _context.Farmers
                .FirstOrDefault(f => f.Id == farmerId)?.Name ?? "Unknown";

            return View(products);
        }

        public IActionResult AddProduct(int farmerId)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            ViewBag.FarmerId = farmerId;
            return View("~/Views/Farmer/AddProduct.cshtml");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddProduct(Product product, int farmerId)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            product.FarmerId = farmerId;

            if (!_validationService.ValidateProduct(product.Name, product.Category, product.ProductionDate.ToString(), out var msg))
            {
                ModelState.AddModelError("", msg);
                return View("~/Views/Farmer/AddProduct.cshtml", product);
            }

            try
            {
                await _context.Products.AddAsync(product);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Product added successfully!";
                return RedirectToAction("ViewProducts", new { farmerId });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error adding product: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while saving the product.");
                return View("~/Views/Farmer/AddProduct.cshtml", product);
            }
        }

        public IActionResult FilterProducts(string startDate, string endDate, string category)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            ViewBag.StartDate = startDate;
            ViewBag.EndDate = endDate;
            ViewBag.Category = category;

            var query = _context.Products.AsQueryable();

            if (DateTime.TryParse(startDate, out DateTime start))
                query = query.Where(p => p.ProductionDate >= start);

            if (DateTime.TryParse(endDate, out DateTime end))
                query = query.Where(p => p.ProductionDate <= end);

            if (!string.IsNullOrWhiteSpace(category))
                query = query.Where(p => EF.Functions.Like(p.Category, $"%{category}%"));

            var results = query.Include(p => p.Farmer).ToList();
            return View(results);
        }

        public IActionResult GoToHomepage()
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            return RedirectToAction("Index", "Home");
        }

        public IActionResult EditFarmer(int id)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            var farmer = _context.Farmers.Find(id);
            if (farmer == null)
                return NotFound();

            return View(farmer);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditFarmer(Farmer updatedFarmer)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            if (!_validationService.ValidateFarmer(updatedFarmer.Name, updatedFarmer.ContactInfo, out var errorMessage))
            {
                ModelState.AddModelError("", errorMessage);
                return View(updatedFarmer);
            }

            var existingFarmer = await _context.Farmers.FindAsync(updatedFarmer.Id);
            if (existingFarmer == null)
                return NotFound();

            existingFarmer.Name = updatedFarmer.Name;
            existingFarmer.ContactInfo = updatedFarmer.ContactInfo;
            existingFarmer.Username = updatedFarmer.Username;
            existingFarmer.Password = updatedFarmer.Password;
            existingFarmer.Role = updatedFarmer.Role;

            try
            {
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Farmer profile updated successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating farmer: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while updating the farmer profile.");
                return View(updatedFarmer);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteFarmer(int id)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            var farmer = await _context.Farmers.FindAsync(id);
            if (farmer == null)
                return NotFound();

            try
            {
                _context.Farmers.Remove(farmer);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Farmer deleted successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting farmer: {ex.Message}");
                TempData["ErrorMessage"] = "An error occurred while deleting the farmer.";
                return RedirectToAction("Index");
            }
        }

        public IActionResult EditProduct(int id)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            var product = _context.Products.Find(id);
            if (product == null)
                return NotFound();

            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProduct(Product updatedProduct)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            if (!_validationService.ValidateProduct(updatedProduct.Name, updatedProduct.Category, updatedProduct.ProductionDate.ToString(), out var msg))
            {
                ModelState.AddModelError("", msg);
                return View(updatedProduct);
            }

            var existingProduct = await _context.Products.FindAsync(updatedProduct.Id);
            if (existingProduct == null)
                return NotFound();

            existingProduct.Name = updatedProduct.Name;
            existingProduct.Category = updatedProduct.Category;
            existingProduct.ProductionDate = updatedProduct.ProductionDate;

            try
            {
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Product updated successfully!";
                return RedirectToAction("ViewProducts", new { farmerId = existingProduct.FarmerId });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating product: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while updating the product.");
                return View(updatedProduct);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            if (!IsAuthorized("Employee"))
                return RedirectToLogin();

            var product = await _context.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            try
            {
                int farmerId = product.FarmerId;
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Product deleted successfully!";
                return RedirectToAction("ViewProducts", new { farmerId });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deleting product: {ex.Message}");
                TempData["ErrorMessage"] = "An error occurred while deleting the product.";
                return RedirectToAction("ViewProducts", new { farmerId = product.FarmerId });
            }
        }
    }
}
