﻿using AgriEnergyConnectPrototype.Data;
using AgriEnergyConnectPrototype.Models;
using AgriEnergyConnectPrototype.Services;
using BCrypt.Net; // For secure password hashing
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

// Create the builder to configure the host and services
var builder = WebApplication.CreateBuilder(args);

// Add MVC controllers and views support
builder.Services.AddControllersWithViews();

// Enable IHttpContextAccessor so we can access session in services like AuthService
builder.Services.AddHttpContextAccessor();

// Configure session management
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Session timeout duration
    options.Cookie.HttpOnly = true;               // Helps prevent XSS attacks
    options.Cookie.IsEssential = true;            // Always keep session available
});

// Register the AppDbContext using InMemoryDatabase for development/demo purposes
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseInMemoryDatabase("AgriDb"));

// Register custom services as scoped (one instance per request)
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<ValidationService>();

// Build the application
var app = builder.Build();

// Ensure database is created (only applies to InMemory for this project)
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    dbContext.Database.EnsureCreated(); // Just creates the DB if it doesn't exist, no seeding
}

// Configure the middleware pipeline

if (!app.Environment.IsDevelopment())
{
    // Use exception handler and HSTS in production-like environments
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    // Show detailed error page during development
    app.UseDeveloperExceptionPage();
}

// Enforce HTTPS and serve static files (CSS, JS, images)
app.UseHttpsRedirection();
app.UseStaticFiles();

// Enable routing and session
app.UseRouting();
app.UseSession(); // Enables session state middleware
app.UseAuthorization(); // Enables role-based authorization

// Define default route: {controller=Home}/{action=Index}/{id?}
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Start the application
app.Run();