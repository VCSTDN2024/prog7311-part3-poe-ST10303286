﻿using System.Linq;
using BCrypt.Net; // For secure password hashing and verification
using Microsoft.AspNetCore.Http;

namespace AgriEnergyConnectPrototype.Services
{
    /// <summary>
    /// Service responsible for user authentication, session management, and password security.
    /// Uses in-memory storage for demo purposes and supports role-based access control.
    /// </summary>
    public class AuthService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// Initializes a new instance of the <see cref="AuthService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">Provides access to HTTP context for session management.</param>
        public AuthService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        // Simulated in-memory user storage with hashed passwords
        private static readonly List<(string Username, string HashedPassword, string Role)> _users = new()
        {
            ("farmer1", HashPassword("password123"), "Farmer"),
            ("employee1", HashPassword("password123"), "Employee")
        };

        /// <summary>
        /// Authenticates a user by checking username and verifying hashed password.
        /// If successful, sets user role and ID in session.
        /// </summary>
        /// <param name="username">The username provided by the user.</param>
        /// <param name="password">The password provided by the user.</param>
        /// <param name="role">Output parameter indicating the user's role if authenticated.</param>
        /// <returns>True if the user is authenticated; otherwise false.</returns>
        public bool Authenticate(string username, string password, out string role)
        {
            var user = _users.FirstOrDefault(u => u.Username == username);

            if (user != default && VerifyPassword(password, user.HashedPassword))
            {
                role = user.Role;
                SetUserRoleAndId(user.Role, _users.IndexOf(user) + 1); // Simulate unique ID
                return true;
            }

            role = null;
            return false;
        }

        /// <summary>
        /// Logs out the current user by clearing session data.
        /// </summary>
        public void Logout()
        {
            var session = _httpContextAccessor.HttpContext.Session;
            session.Clear();
        }

        /// <summary>
        /// Checks whether the current user is authenticated.
        /// </summary>
        /// <returns>True if the user is logged in; otherwise false.</returns>
        public bool IsAuthenticated()
        {
            var session = _httpContextAccessor.HttpContext.Session;
            return !string.IsNullOrEmpty(session.GetString("UserRole"));
        }

        /// <summary>
        /// Gets the role of the currently authenticated user.
        /// </summary>
        /// <returns>The user's role as a string (e.g., "Farmer", "Employee").</returns>
        public string GetUserRole()
        {
            var session = _httpContextAccessor.HttpContext.Session;
            return session.GetString("UserRole");
        }

        /// <summary>
        /// Checks if a given username is available for registration.
        /// </summary>
        /// <param name="username">The username to check.</param>
        /// <returns>True if the username is not taken; otherwise false.</returns>
        public bool IsUsernameAvailable(string username)
        {
            return !_users.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Registers a new user with the specified username, password, and role.
        /// The password is stored securely using hashing.
        /// </summary>
        /// <param name="username">The username chosen by the user.</param>
        /// <param name="password">The password entered by the user.</param>
        /// <param name="role">The assigned role (e.g., Farmer or Employee).</param>
        public void Register(string username, string password, string role)
        {
            _users.Add((username, HashPassword(password), role));
        }

        /// <summary>
        /// Sets the user's role and ID in session after successful login or registration.
        /// Also stores the username for display purposes.
        /// </summary>
        /// <param name="role">The role of the authenticated user.</param>
        /// <param name="userId">A simulated unique ID for the user.</param>
        private void SetUserRoleAndId(string role, int userId)
        {
            var session = _httpContextAccessor.HttpContext.Session;
            session.SetString("UserRole", role);
            session.SetInt32("UserId", userId);
            session.SetString("Username", _users[userId - 1].Username); // Save username too
        }

        #region Password Security Helpers

        /// <summary>
        /// Hashes a plaintext password using BCrypt for secure storage.
        /// </summary>
        /// <param name="password">The password to hash.</param>
        /// <returns>A hashed representation of the password.</returns>
        private static string HashPassword(string password) =>
            BCrypt.Net.BCrypt.HashPassword(password, BCrypt.Net.BCrypt.GenerateSalt());

        /// <summary>
        /// Verifies that the provided password matches the stored hashed password.
        /// </summary>
        /// <param name="password">The password provided by the user.</param>
        /// <param name="hashed">The stored hashed password.</param>
        /// <returns>True if the password is valid; otherwise false.</returns>
        private static bool VerifyPassword(string password, string hashed) =>
            BCrypt.Net.BCrypt.Verify(password, hashed);

        #endregion
    }
}